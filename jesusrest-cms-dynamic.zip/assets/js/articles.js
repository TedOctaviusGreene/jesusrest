
async function renderArticles(){
  const el = document.querySelector('#articles-list');
  if(!el) return;
  try{
    const res = await fetch('/articles/index.json', {cache:'no-store'});
    const items = await res.json();
    items.sort((a,b)=> new Date(b.date) - new Date(a.date));
    el.innerHTML = items.map(it => `
      <article class="card">
        <div class="badge">${new Date(it.date).toLocaleDateString()}</div>
        <h3><a href="/read.html?slug=${encodeURIComponent(it.slug)}">${it.title}</a></h3>
        <p class="small">${it.summary||''}</p>
      </article>
    `).join('');
  }catch(e){
    el.innerHTML = '<p class="small">Articles will appear here.</p>';
  }
}
document.addEventListener('DOMContentLoaded', renderArticles);
